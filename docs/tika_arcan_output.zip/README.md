# Arcan output for Apache Tika

Detector: **Arcan 1.2.1**, the jar in `tools/arcan-1.2.1`, run as
`java -jar arcan-1.2.1.jar -p <repo> -out <dir> -all`.

Subject: **Apache Tika at commit `697d7c047daf1f661a4ed067bbc8f9c58bb6faa2`** — the same
`versionId` the model's suggestion file targets.

Build state at measurement: **101 of 102 reactor modules, 1,804 class files**. `tika-grpc` cannot
build on this machine (its protobuf plugin needs a `protoc-gen-grpc-java` binary that is not
installed); that is an environment limitation unrelated to any refactoring, and the same
exclusion is applied to every after-measurement so the two stay comparable.

**Total: 260 smells** — 173 Cyclic Dependency, 86 Unstable Dependency, 1 Hub-Like Dependency.

That total reconciles exactly against the raw files below:

    68   rows in packageCyclicDependencyTable.csv   (package-level cycles)
  + 105  rows in classCyclicDependencyTable.csv     (class-level cycles)
  +  78  rows in UD.csv                             (unstable dependencies)
  +   8  rows in UD30.csv                           (unstable dependencies, 30% threshold)
  +   1  row  in HL.csv                             (hub-like)
  = 260

Reading only `UD.csv` and missing `UD30.csv` gives 252, which is how a conversion bug was caught.

---

## 01_baseline_before/ — raw Arcan 1.2.1 output, untouched

| File | What it holds |
|---|---|
| `CM.csv` | Class metrics: `Class, FI, FO, CBO, LCOM` |
| `PM.csv` | Package metrics: `Package, CA, CE, RMI, RMA, RMD` |
| `HL.csv` | Hub-like dependencies: `Class, FanIn, FanOut, Total Dependences` |
| `UD.csv` | Unstable dependencies: unstable package, its instability, the correlated package, its instability |
| `UD30.csv` | The same at the 30% threshold. **Both files count toward the total.** |
| `packageCyclicDependencyTable.csv` | Membership matrix: one row per cycle, one column per package, `1` = member |
| `classCyclicDependencyTable.csv` | The same at class level |
| `packageCyclesShapeTable.csv` | Shape classification per package cycle (circle, clique, chain, star, tiny) |
| `classCyclesShapeTable.csv` | The same at class level |
| `packageCyclicDependencyMatrix.csv` | Full package adjacency matrix |
| `classCyclicDependencyMatrix.csv` | Full class adjacency matrix (21 MB; mostly zeros) |

A cycle's identity is **the set of members in its matrix row**. That is how before/after
comparison is done here — by identity, not by count, because a count cannot tell a surviving
cycle from a new one that replaced it.

## 02_converted_to_server_schema/ — the three CSVs the DSARP web UI expects

Arcan 1.2.1's CLI writes the files above. The `DSARP-OpenRewrite` dashboard validates a different,
server-style export, so these are derived from the raw output by
`dsarp/experiments/arcan_to_baseline_csv.py` and are accepted by that repository's own
`evaluation/validate_baseline_inputs.py`.

| File | Required columns |
|---|---|
| `component-metrics.csv` | `project, versionId, ComponentType, name` (+ FanIn, FanOut, CBO, LCOM) |
| `smell-characteristics.csv` | `project, versionId, smellType, AffectedConstructType, AffectedElements` |
| `smell-affects.csv` | `project, versionId, from, to` |

Nothing is invented: every row is derived from a file Arcan actually wrote.

## 03_after_tika-C8_clean_win/ — the one unambiguous improvement

Arcan output for the Tika tree after batch **tika-C8**, the only change among 37 comparable
batches that improves on every measure taken.

- One class relocated: `org.apache.tika.server.core.MetadataList` → `org.apache.tika.server.core.writer`
- **260 → 258 smells.** Two removed, **none created**.
- Removed: the package cycle `org.apache.tika.server.core` ↔ `org.apache.tika.server.core.writer`,
  and the unstable dependency between the same two packages.
- Package cycles 68 → 67. Build green, all 101 modules.

Diff it against `01_baseline_before/` to see those two smells disappear and nothing take their
place. `dsarp/experiments/arcan_diff.py` does this by identity.
